/* Offline cache. Bump CACHE whenever you change any file in this list or in data/. */
const CACHE = 'lian-v2';
const ASSETS = ['./','index.html','cards.html','styles.css','app.js',
  'data/sentences.js','data/pairs.js','data/grammar.js','data/stories.js',
  'data/summaries.js','data/strokechars.js','data/talk.js','data/vocab.js',
  'vendor/hanzi-writer.min.js',
  'manifest.webmanifest','icon-192.png','icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
/* Stroke files and fonts are cached the first time they're used. */
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request).then(res => {
    if (res && res.ok && res.type === 'basic') {
      const copy = res.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy));
    }
    return res;
  }).catch(() => caches.match('index.html'))));
});
